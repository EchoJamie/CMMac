﻿namespace CLA
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Input = new System.Windows.Forms.GroupBox();
            this.AnswerBin = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.AnswerDec = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Num2bin = new System.Windows.Forms.TextBox();
            this.Num1bin = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Num2dec = new System.Windows.Forms.TextBox();
            this.Num1dec = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.InputData = new System.Windows.Forms.GroupBox();
            this.b1text = new System.Windows.Forms.TextBox();
            this.b2text = new System.Windows.Forms.TextBox();
            this.b0text = new System.Windows.Forms.TextBox();
            this.b3text = new System.Windows.Forms.TextBox();
            this.b4text = new System.Windows.Forms.TextBox();
            this.b5text = new System.Windows.Forms.TextBox();
            this.b6text = new System.Windows.Forms.TextBox();
            this.b7text = new System.Windows.Forms.TextBox();
            this.a1text = new System.Windows.Forms.TextBox();
            this.a2text = new System.Windows.Forms.TextBox();
            this.a0text = new System.Windows.Forms.TextBox();
            this.a3text = new System.Windows.Forms.TextBox();
            this.a4text = new System.Windows.Forms.TextBox();
            this.a5text = new System.Windows.Forms.TextBox();
            this.a6text = new System.Windows.Forms.TextBox();
            this.a7text = new System.Windows.Forms.TextBox();
            this.b1l = new System.Windows.Forms.Label();
            this.b0l = new System.Windows.Forms.Label();
            this.b2l = new System.Windows.Forms.Label();
            this.b7l = new System.Windows.Forms.Label();
            this.b3l = new System.Windows.Forms.Label();
            this.b6l = new System.Windows.Forms.Label();
            this.b4l = new System.Windows.Forms.Label();
            this.b5l = new System.Windows.Forms.Label();
            this.a1l = new System.Windows.Forms.Label();
            this.a0l = new System.Windows.Forms.Label();
            this.a2l = new System.Windows.Forms.Label();
            this.a7l = new System.Windows.Forms.Label();
            this.a3l = new System.Windows.Forms.Label();
            this.a6l = new System.Windows.Forms.Label();
            this.a4l = new System.Windows.Forms.Label();
            this.a5l = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.t1text = new System.Windows.Forms.TextBox();
            this.t2text = new System.Windows.Forms.TextBox();
            this.t0text = new System.Windows.Forms.TextBox();
            this.t3text = new System.Windows.Forms.TextBox();
            this.t4text = new System.Windows.Forms.TextBox();
            this.t5text = new System.Windows.Forms.TextBox();
            this.t6text = new System.Windows.Forms.TextBox();
            this.t7text = new System.Windows.Forms.TextBox();
            this.t1l = new System.Windows.Forms.Label();
            this.t0l = new System.Windows.Forms.Label();
            this.t2l = new System.Windows.Forms.Label();
            this.t7l = new System.Windows.Forms.Label();
            this.t3l = new System.Windows.Forms.Label();
            this.t6l = new System.Windows.Forms.Label();
            this.t4l = new System.Windows.Forms.Label();
            this.t5l = new System.Windows.Forms.Label();
            this.d1text = new System.Windows.Forms.TextBox();
            this.d2text = new System.Windows.Forms.TextBox();
            this.d0text = new System.Windows.Forms.TextBox();
            this.d3text = new System.Windows.Forms.TextBox();
            this.d4text = new System.Windows.Forms.TextBox();
            this.d5text = new System.Windows.Forms.TextBox();
            this.d6text = new System.Windows.Forms.TextBox();
            this.d7text = new System.Windows.Forms.TextBox();
            this.c2text = new System.Windows.Forms.TextBox();
            this.c3text = new System.Windows.Forms.TextBox();
            this.c1text = new System.Windows.Forms.TextBox();
            this.c4text = new System.Windows.Forms.TextBox();
            this.c5text = new System.Windows.Forms.TextBox();
            this.c6text = new System.Windows.Forms.TextBox();
            this.c7text = new System.Windows.Forms.TextBox();
            this.c8text = new System.Windows.Forms.TextBox();
            this.d1l = new System.Windows.Forms.Label();
            this.d0l = new System.Windows.Forms.Label();
            this.d2l = new System.Windows.Forms.Label();
            this.d7l = new System.Windows.Forms.Label();
            this.d3l = new System.Windows.Forms.Label();
            this.d6l = new System.Windows.Forms.Label();
            this.d4l = new System.Windows.Forms.Label();
            this.d5l = new System.Windows.Forms.Label();
            this.c2l = new System.Windows.Forms.Label();
            this.c1l = new System.Windows.Forms.Label();
            this.c3l = new System.Windows.Forms.Label();
            this.c8l = new System.Windows.Forms.Label();
            this.c4l = new System.Windows.Forms.Label();
            this.c7l = new System.Windows.Forms.Label();
            this.c5l = new System.Windows.Forms.Label();
            this.c6l = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Input.SuspendLayout();
            this.InputData.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Input
            // 
            this.Input.Controls.Add(this.AnswerBin);
            this.Input.Controls.Add(this.label3);
            this.Input.Controls.Add(this.AnswerDec);
            this.Input.Controls.Add(this.label4);
            this.Input.Controls.Add(this.Num2bin);
            this.Input.Controls.Add(this.Num1bin);
            this.Input.Controls.Add(this.label11);
            this.Input.Controls.Add(this.label12);
            this.Input.Controls.Add(this.Num2dec);
            this.Input.Controls.Add(this.Num1dec);
            this.Input.Controls.Add(this.label2);
            this.Input.Controls.Add(this.label1);
            this.Input.Location = new System.Drawing.Point(6, 0);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(200, 200);
            this.Input.TabIndex = 0;
            this.Input.TabStop = false;
            this.Input.Text = "input";
            // 
            // AnswerBin
            // 
            this.AnswerBin.Location = new System.Drawing.Point(119, 161);
            this.AnswerBin.Name = "AnswerBin";
            this.AnswerBin.ReadOnly = true;
            this.AnswerBin.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.AnswerBin.Size = new System.Drawing.Size(70, 25);
            this.AnswerBin.TabIndex = 10;
            this.AnswerBin.TabStop = false;
            this.AnswerBin.Text = "00000000";
            this.AnswerBin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "结  果：(bin)";
            // 
            // AnswerDec
            // 
            this.AnswerDec.Location = new System.Drawing.Point(119, 133);
            this.AnswerDec.Name = "AnswerDec";
            this.AnswerDec.ReadOnly = true;
            this.AnswerDec.Size = new System.Drawing.Size(70, 25);
            this.AnswerDec.TabIndex = 8;
            this.AnswerDec.TabStop = false;
            this.AnswerDec.Text = "0";
            this.AnswerDec.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "结  果：(dec)";
            // 
            // Num2bin
            // 
            this.Num2bin.Location = new System.Drawing.Point(119, 105);
            this.Num2bin.Name = "Num2bin";
            this.Num2bin.ReadOnly = true;
            this.Num2bin.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Num2bin.Size = new System.Drawing.Size(70, 25);
            this.Num2bin.TabIndex = 6;
            this.Num2bin.TabStop = false;
            this.Num2bin.Text = "00000000";
            this.Num2bin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Num1bin
            // 
            this.Num1bin.Location = new System.Drawing.Point(119, 49);
            this.Num1bin.Name = "Num1bin";
            this.Num1bin.ReadOnly = true;
            this.Num1bin.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Num1bin.Size = new System.Drawing.Size(70, 25);
            this.Num1bin.TabIndex = 4;
            this.Num1bin.TabStop = false;
            this.Num1bin.Text = "00000000";
            this.Num1bin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 110);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 15);
            this.label11.TabIndex = 5;
            this.label11.Text = "加  数：(bin)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 54);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(107, 15);
            this.label12.TabIndex = 3;
            this.label12.Text = "被加数：(bin)";
            // 
            // Num2dec
            // 
            this.Num2dec.Location = new System.Drawing.Point(119, 77);
            this.Num2dec.Name = "Num2dec";
            this.Num2dec.Size = new System.Drawing.Size(70, 25);
            this.Num2dec.TabIndex = 2;
            this.Num2dec.Text = "0";
            this.Num2dec.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Num2dec.Leave += new System.EventHandler(this.Num2_Leave);
            // 
            // Num1dec
            // 
            this.Num1dec.Location = new System.Drawing.Point(119, 21);
            this.Num1dec.Name = "Num1dec";
            this.Num1dec.Size = new System.Drawing.Size(70, 25);
            this.Num1dec.TabIndex = 1;
            this.Num1dec.Text = "0";
            this.Num1dec.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Num1dec.Leave += new System.EventHandler(this.Num1_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "加  数：(dec)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "被加数：(dec)";
            // 
            // InputData
            // 
            this.InputData.Controls.Add(this.b1text);
            this.InputData.Controls.Add(this.b2text);
            this.InputData.Controls.Add(this.b0text);
            this.InputData.Controls.Add(this.b3text);
            this.InputData.Controls.Add(this.b4text);
            this.InputData.Controls.Add(this.b5text);
            this.InputData.Controls.Add(this.b6text);
            this.InputData.Controls.Add(this.b7text);
            this.InputData.Controls.Add(this.a1text);
            this.InputData.Controls.Add(this.a2text);
            this.InputData.Controls.Add(this.a0text);
            this.InputData.Controls.Add(this.a3text);
            this.InputData.Controls.Add(this.a4text);
            this.InputData.Controls.Add(this.a5text);
            this.InputData.Controls.Add(this.a6text);
            this.InputData.Controls.Add(this.a7text);
            this.InputData.Controls.Add(this.b1l);
            this.InputData.Controls.Add(this.b0l);
            this.InputData.Controls.Add(this.b2l);
            this.InputData.Controls.Add(this.b7l);
            this.InputData.Controls.Add(this.b3l);
            this.InputData.Controls.Add(this.b6l);
            this.InputData.Controls.Add(this.b4l);
            this.InputData.Controls.Add(this.b5l);
            this.InputData.Controls.Add(this.a1l);
            this.InputData.Controls.Add(this.a0l);
            this.InputData.Controls.Add(this.a2l);
            this.InputData.Controls.Add(this.a7l);
            this.InputData.Controls.Add(this.a3l);
            this.InputData.Controls.Add(this.a6l);
            this.InputData.Controls.Add(this.a4l);
            this.InputData.Controls.Add(this.a5l);
            this.InputData.Location = new System.Drawing.Point(218, 0);
            this.InputData.Name = "InputData";
            this.InputData.Size = new System.Drawing.Size(715, 83);
            this.InputData.TabIndex = 1;
            this.InputData.TabStop = false;
            this.InputData.Text = "InputData";
            // 
            // b1text
            // 
            this.b1text.Location = new System.Drawing.Point(564, 49);
            this.b1text.Name = "b1text";
            this.b1text.ReadOnly = true;
            this.b1text.Size = new System.Drawing.Size(36, 25);
            this.b1text.TabIndex = 33;
            this.b1text.TabStop = false;
            this.b1text.Text = "0";
            this.b1text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b2text
            // 
            this.b2text.Location = new System.Drawing.Point(477, 49);
            this.b2text.Name = "b2text";
            this.b2text.ReadOnly = true;
            this.b2text.Size = new System.Drawing.Size(36, 25);
            this.b2text.TabIndex = 32;
            this.b2text.TabStop = false;
            this.b2text.Text = "0";
            this.b2text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b0text
            // 
            this.b0text.Location = new System.Drawing.Point(651, 49);
            this.b0text.Name = "b0text";
            this.b0text.ReadOnly = true;
            this.b0text.Size = new System.Drawing.Size(36, 25);
            this.b0text.TabIndex = 31;
            this.b0text.TabStop = false;
            this.b0text.Text = "0";
            this.b0text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b3text
            // 
            this.b3text.Location = new System.Drawing.Point(390, 49);
            this.b3text.Name = "b3text";
            this.b3text.ReadOnly = true;
            this.b3text.Size = new System.Drawing.Size(36, 25);
            this.b3text.TabIndex = 30;
            this.b3text.TabStop = false;
            this.b3text.Text = "0";
            this.b3text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b4text
            // 
            this.b4text.Location = new System.Drawing.Point(303, 49);
            this.b4text.Name = "b4text";
            this.b4text.ReadOnly = true;
            this.b4text.Size = new System.Drawing.Size(36, 25);
            this.b4text.TabIndex = 29;
            this.b4text.TabStop = false;
            this.b4text.Text = "0";
            this.b4text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b5text
            // 
            this.b5text.Location = new System.Drawing.Point(216, 49);
            this.b5text.Name = "b5text";
            this.b5text.ReadOnly = true;
            this.b5text.Size = new System.Drawing.Size(36, 25);
            this.b5text.TabIndex = 28;
            this.b5text.TabStop = false;
            this.b5text.Text = "0";
            this.b5text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b6text
            // 
            this.b6text.Location = new System.Drawing.Point(129, 49);
            this.b6text.Name = "b6text";
            this.b6text.ReadOnly = true;
            this.b6text.Size = new System.Drawing.Size(36, 25);
            this.b6text.TabIndex = 27;
            this.b6text.TabStop = false;
            this.b6text.Text = "0";
            this.b6text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b7text
            // 
            this.b7text.Location = new System.Drawing.Point(42, 49);
            this.b7text.Name = "b7text";
            this.b7text.ReadOnly = true;
            this.b7text.Size = new System.Drawing.Size(36, 25);
            this.b7text.TabIndex = 26;
            this.b7text.TabStop = false;
            this.b7text.Text = "0";
            this.b7text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // a1text
            // 
            this.a1text.Location = new System.Drawing.Point(564, 21);
            this.a1text.Name = "a1text";
            this.a1text.ReadOnly = true;
            this.a1text.Size = new System.Drawing.Size(36, 25);
            this.a1text.TabIndex = 25;
            this.a1text.TabStop = false;
            this.a1text.Text = "0";
            this.a1text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // a2text
            // 
            this.a2text.Location = new System.Drawing.Point(477, 21);
            this.a2text.Name = "a2text";
            this.a2text.ReadOnly = true;
            this.a2text.Size = new System.Drawing.Size(36, 25);
            this.a2text.TabIndex = 24;
            this.a2text.TabStop = false;
            this.a2text.Text = "0";
            this.a2text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // a0text
            // 
            this.a0text.Location = new System.Drawing.Point(651, 21);
            this.a0text.Name = "a0text";
            this.a0text.ReadOnly = true;
            this.a0text.Size = new System.Drawing.Size(36, 25);
            this.a0text.TabIndex = 23;
            this.a0text.TabStop = false;
            this.a0text.Text = "0";
            this.a0text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // a3text
            // 
            this.a3text.Location = new System.Drawing.Point(390, 21);
            this.a3text.Name = "a3text";
            this.a3text.ReadOnly = true;
            this.a3text.Size = new System.Drawing.Size(36, 25);
            this.a3text.TabIndex = 22;
            this.a3text.TabStop = false;
            this.a3text.Text = "0";
            this.a3text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // a4text
            // 
            this.a4text.Location = new System.Drawing.Point(303, 21);
            this.a4text.Name = "a4text";
            this.a4text.ReadOnly = true;
            this.a4text.Size = new System.Drawing.Size(36, 25);
            this.a4text.TabIndex = 21;
            this.a4text.TabStop = false;
            this.a4text.Text = "0";
            this.a4text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // a5text
            // 
            this.a5text.Location = new System.Drawing.Point(216, 21);
            this.a5text.Name = "a5text";
            this.a5text.ReadOnly = true;
            this.a5text.Size = new System.Drawing.Size(36, 25);
            this.a5text.TabIndex = 20;
            this.a5text.TabStop = false;
            this.a5text.Text = "0";
            this.a5text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // a6text
            // 
            this.a6text.Location = new System.Drawing.Point(129, 21);
            this.a6text.Name = "a6text";
            this.a6text.ReadOnly = true;
            this.a6text.Size = new System.Drawing.Size(36, 25);
            this.a6text.TabIndex = 19;
            this.a6text.TabStop = false;
            this.a6text.Text = "0";
            this.a6text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // a7text
            // 
            this.a7text.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.a7text.Location = new System.Drawing.Point(42, 21);
            this.a7text.Name = "a7text";
            this.a7text.ReadOnly = true;
            this.a7text.Size = new System.Drawing.Size(36, 25);
            this.a7text.TabIndex = 18;
            this.a7text.TabStop = false;
            this.a7text.Text = "0";
            this.a7text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.a7text.WordWrap = false;
            // 
            // b1l
            // 
            this.b1l.AutoSize = true;
            this.b1l.Location = new System.Drawing.Point(526, 54);
            this.b1l.Name = "b1l";
            this.b1l.Size = new System.Drawing.Size(23, 15);
            this.b1l.TabIndex = 16;
            this.b1l.Text = "b1";
            // 
            // b0l
            // 
            this.b0l.AutoSize = true;
            this.b0l.Location = new System.Drawing.Point(612, 52);
            this.b0l.Name = "b0l";
            this.b0l.Size = new System.Drawing.Size(23, 15);
            this.b0l.TabIndex = 17;
            this.b0l.Text = "b0";
            // 
            // b2l
            // 
            this.b2l.AutoSize = true;
            this.b2l.Location = new System.Drawing.Point(440, 54);
            this.b2l.Name = "b2l";
            this.b2l.Size = new System.Drawing.Size(23, 15);
            this.b2l.TabIndex = 15;
            this.b2l.Text = "b2";
            // 
            // b7l
            // 
            this.b7l.AutoSize = true;
            this.b7l.Location = new System.Drawing.Point(10, 54);
            this.b7l.Name = "b7l";
            this.b7l.Size = new System.Drawing.Size(23, 15);
            this.b7l.TabIndex = 10;
            this.b7l.Text = "b7";
            // 
            // b3l
            // 
            this.b3l.AutoSize = true;
            this.b3l.Location = new System.Drawing.Point(354, 54);
            this.b3l.Name = "b3l";
            this.b3l.Size = new System.Drawing.Size(23, 15);
            this.b3l.TabIndex = 14;
            this.b3l.Text = "b3";
            // 
            // b6l
            // 
            this.b6l.AutoSize = true;
            this.b6l.Location = new System.Drawing.Point(96, 54);
            this.b6l.Name = "b6l";
            this.b6l.Size = new System.Drawing.Size(23, 15);
            this.b6l.TabIndex = 11;
            this.b6l.Text = "b6";
            // 
            // b4l
            // 
            this.b4l.AutoSize = true;
            this.b4l.Location = new System.Drawing.Point(268, 54);
            this.b4l.Name = "b4l";
            this.b4l.Size = new System.Drawing.Size(23, 15);
            this.b4l.TabIndex = 13;
            this.b4l.Text = "b4";
            // 
            // b5l
            // 
            this.b5l.AutoSize = true;
            this.b5l.Location = new System.Drawing.Point(182, 54);
            this.b5l.Name = "b5l";
            this.b5l.Size = new System.Drawing.Size(23, 15);
            this.b5l.TabIndex = 12;
            this.b5l.Text = "b5";
            // 
            // a1l
            // 
            this.a1l.AutoSize = true;
            this.a1l.Location = new System.Drawing.Point(526, 26);
            this.a1l.Name = "a1l";
            this.a1l.Size = new System.Drawing.Size(23, 15);
            this.a1l.TabIndex = 8;
            this.a1l.Text = "a1";
            // 
            // a0l
            // 
            this.a0l.AutoSize = true;
            this.a0l.Location = new System.Drawing.Point(612, 24);
            this.a0l.Name = "a0l";
            this.a0l.Size = new System.Drawing.Size(23, 15);
            this.a0l.TabIndex = 9;
            this.a0l.Text = "a0";
            // 
            // a2l
            // 
            this.a2l.AutoSize = true;
            this.a2l.Location = new System.Drawing.Point(440, 26);
            this.a2l.Name = "a2l";
            this.a2l.Size = new System.Drawing.Size(23, 15);
            this.a2l.TabIndex = 7;
            this.a2l.Text = "a2";
            // 
            // a7l
            // 
            this.a7l.AutoSize = true;
            this.a7l.Location = new System.Drawing.Point(10, 26);
            this.a7l.Name = "a7l";
            this.a7l.Size = new System.Drawing.Size(23, 15);
            this.a7l.TabIndex = 2;
            this.a7l.Text = "a7";
            // 
            // a3l
            // 
            this.a3l.AutoSize = true;
            this.a3l.Location = new System.Drawing.Point(354, 26);
            this.a3l.Name = "a3l";
            this.a3l.Size = new System.Drawing.Size(23, 15);
            this.a3l.TabIndex = 6;
            this.a3l.Text = "a3";
            // 
            // a6l
            // 
            this.a6l.AutoSize = true;
            this.a6l.Location = new System.Drawing.Point(96, 26);
            this.a6l.Name = "a6l";
            this.a6l.Size = new System.Drawing.Size(23, 15);
            this.a6l.TabIndex = 3;
            this.a6l.Text = "a6";
            // 
            // a4l
            // 
            this.a4l.AutoSize = true;
            this.a4l.Location = new System.Drawing.Point(268, 26);
            this.a4l.Name = "a4l";
            this.a4l.Size = new System.Drawing.Size(23, 15);
            this.a4l.TabIndex = 5;
            this.a4l.Text = "a4";
            // 
            // a5l
            // 
            this.a5l.AutoSize = true;
            this.a5l.Location = new System.Drawing.Point(182, 26);
            this.a5l.Name = "a5l";
            this.a5l.Size = new System.Drawing.Size(23, 15);
            this.a5l.TabIndex = 4;
            this.a5l.Text = "a5";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.t1text);
            this.groupBox1.Controls.Add(this.t2text);
            this.groupBox1.Controls.Add(this.t0text);
            this.groupBox1.Controls.Add(this.t3text);
            this.groupBox1.Controls.Add(this.t4text);
            this.groupBox1.Controls.Add(this.t5text);
            this.groupBox1.Controls.Add(this.t6text);
            this.groupBox1.Controls.Add(this.t7text);
            this.groupBox1.Controls.Add(this.t1l);
            this.groupBox1.Controls.Add(this.t0l);
            this.groupBox1.Controls.Add(this.t2l);
            this.groupBox1.Controls.Add(this.t7l);
            this.groupBox1.Controls.Add(this.t3l);
            this.groupBox1.Controls.Add(this.t6l);
            this.groupBox1.Controls.Add(this.t4l);
            this.groupBox1.Controls.Add(this.t5l);
            this.groupBox1.Controls.Add(this.d1text);
            this.groupBox1.Controls.Add(this.d2text);
            this.groupBox1.Controls.Add(this.d0text);
            this.groupBox1.Controls.Add(this.d3text);
            this.groupBox1.Controls.Add(this.d4text);
            this.groupBox1.Controls.Add(this.d5text);
            this.groupBox1.Controls.Add(this.d6text);
            this.groupBox1.Controls.Add(this.d7text);
            this.groupBox1.Controls.Add(this.c2text);
            this.groupBox1.Controls.Add(this.c3text);
            this.groupBox1.Controls.Add(this.c1text);
            this.groupBox1.Controls.Add(this.c4text);
            this.groupBox1.Controls.Add(this.c5text);
            this.groupBox1.Controls.Add(this.c6text);
            this.groupBox1.Controls.Add(this.c7text);
            this.groupBox1.Controls.Add(this.c8text);
            this.groupBox1.Controls.Add(this.d1l);
            this.groupBox1.Controls.Add(this.d0l);
            this.groupBox1.Controls.Add(this.d2l);
            this.groupBox1.Controls.Add(this.d7l);
            this.groupBox1.Controls.Add(this.d3l);
            this.groupBox1.Controls.Add(this.d6l);
            this.groupBox1.Controls.Add(this.d4l);
            this.groupBox1.Controls.Add(this.d5l);
            this.groupBox1.Controls.Add(this.c2l);
            this.groupBox1.Controls.Add(this.c1l);
            this.groupBox1.Controls.Add(this.c3l);
            this.groupBox1.Controls.Add(this.c8l);
            this.groupBox1.Controls.Add(this.c4l);
            this.groupBox1.Controls.Add(this.c7l);
            this.groupBox1.Controls.Add(this.c5l);
            this.groupBox1.Controls.Add(this.c6l);
            this.groupBox1.Location = new System.Drawing.Point(218, 89);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(715, 111);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Middle Information";
            // 
            // t1text
            // 
            this.t1text.Location = new System.Drawing.Point(564, 77);
            this.t1text.Name = "t1text";
            this.t1text.ReadOnly = true;
            this.t1text.Size = new System.Drawing.Size(36, 25);
            this.t1text.TabIndex = 49;
            this.t1text.TabStop = false;
            this.t1text.Text = "0";
            this.t1text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // t2text
            // 
            this.t2text.Location = new System.Drawing.Point(477, 77);
            this.t2text.Name = "t2text";
            this.t2text.ReadOnly = true;
            this.t2text.Size = new System.Drawing.Size(36, 25);
            this.t2text.TabIndex = 48;
            this.t2text.TabStop = false;
            this.t2text.Text = "0";
            this.t2text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // t0text
            // 
            this.t0text.Location = new System.Drawing.Point(651, 77);
            this.t0text.Name = "t0text";
            this.t0text.ReadOnly = true;
            this.t0text.Size = new System.Drawing.Size(36, 25);
            this.t0text.TabIndex = 47;
            this.t0text.TabStop = false;
            this.t0text.Text = "0";
            this.t0text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // t3text
            // 
            this.t3text.Location = new System.Drawing.Point(390, 77);
            this.t3text.Name = "t3text";
            this.t3text.ReadOnly = true;
            this.t3text.Size = new System.Drawing.Size(36, 25);
            this.t3text.TabIndex = 46;
            this.t3text.TabStop = false;
            this.t3text.Text = "0";
            this.t3text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // t4text
            // 
            this.t4text.Location = new System.Drawing.Point(303, 77);
            this.t4text.Name = "t4text";
            this.t4text.ReadOnly = true;
            this.t4text.Size = new System.Drawing.Size(36, 25);
            this.t4text.TabIndex = 45;
            this.t4text.TabStop = false;
            this.t4text.Text = "0";
            this.t4text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // t5text
            // 
            this.t5text.Location = new System.Drawing.Point(216, 77);
            this.t5text.Name = "t5text";
            this.t5text.ReadOnly = true;
            this.t5text.Size = new System.Drawing.Size(36, 25);
            this.t5text.TabIndex = 44;
            this.t5text.TabStop = false;
            this.t5text.Text = "0";
            this.t5text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // t6text
            // 
            this.t6text.Location = new System.Drawing.Point(129, 77);
            this.t6text.Name = "t6text";
            this.t6text.ReadOnly = true;
            this.t6text.Size = new System.Drawing.Size(36, 25);
            this.t6text.TabIndex = 43;
            this.t6text.TabStop = false;
            this.t6text.Text = "0";
            this.t6text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // t7text
            // 
            this.t7text.Location = new System.Drawing.Point(42, 77);
            this.t7text.Name = "t7text";
            this.t7text.ReadOnly = true;
            this.t7text.Size = new System.Drawing.Size(36, 25);
            this.t7text.TabIndex = 42;
            this.t7text.TabStop = false;
            this.t7text.Text = "0";
            this.t7text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // t1l
            // 
            this.t1l.AutoSize = true;
            this.t1l.Location = new System.Drawing.Point(526, 82);
            this.t1l.Name = "t1l";
            this.t1l.Size = new System.Drawing.Size(23, 15);
            this.t1l.TabIndex = 40;
            this.t1l.Text = "t1";
            // 
            // t0l
            // 
            this.t0l.AutoSize = true;
            this.t0l.Location = new System.Drawing.Point(612, 80);
            this.t0l.Name = "t0l";
            this.t0l.Size = new System.Drawing.Size(23, 15);
            this.t0l.TabIndex = 41;
            this.t0l.Text = "t0";
            // 
            // t2l
            // 
            this.t2l.AutoSize = true;
            this.t2l.Location = new System.Drawing.Point(440, 82);
            this.t2l.Name = "t2l";
            this.t2l.Size = new System.Drawing.Size(23, 15);
            this.t2l.TabIndex = 39;
            this.t2l.Text = "t2";
            // 
            // t7l
            // 
            this.t7l.AutoSize = true;
            this.t7l.Location = new System.Drawing.Point(10, 82);
            this.t7l.Name = "t7l";
            this.t7l.Size = new System.Drawing.Size(23, 15);
            this.t7l.TabIndex = 34;
            this.t7l.Text = "t7";
            // 
            // t3l
            // 
            this.t3l.AutoSize = true;
            this.t3l.Location = new System.Drawing.Point(354, 82);
            this.t3l.Name = "t3l";
            this.t3l.Size = new System.Drawing.Size(23, 15);
            this.t3l.TabIndex = 38;
            this.t3l.Text = "t3";
            // 
            // t6l
            // 
            this.t6l.AutoSize = true;
            this.t6l.Location = new System.Drawing.Point(96, 82);
            this.t6l.Name = "t6l";
            this.t6l.Size = new System.Drawing.Size(23, 15);
            this.t6l.TabIndex = 35;
            this.t6l.Text = "t6";
            // 
            // t4l
            // 
            this.t4l.AutoSize = true;
            this.t4l.Location = new System.Drawing.Point(268, 82);
            this.t4l.Name = "t4l";
            this.t4l.Size = new System.Drawing.Size(23, 15);
            this.t4l.TabIndex = 37;
            this.t4l.Text = "t4";
            // 
            // t5l
            // 
            this.t5l.AutoSize = true;
            this.t5l.Location = new System.Drawing.Point(182, 82);
            this.t5l.Name = "t5l";
            this.t5l.Size = new System.Drawing.Size(23, 15);
            this.t5l.TabIndex = 36;
            this.t5l.Text = "t5";
            // 
            // d1text
            // 
            this.d1text.Location = new System.Drawing.Point(564, 49);
            this.d1text.Name = "d1text";
            this.d1text.ReadOnly = true;
            this.d1text.Size = new System.Drawing.Size(36, 25);
            this.d1text.TabIndex = 33;
            this.d1text.TabStop = false;
            this.d1text.Text = "0";
            this.d1text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // d2text
            // 
            this.d2text.Location = new System.Drawing.Point(477, 49);
            this.d2text.Name = "d2text";
            this.d2text.ReadOnly = true;
            this.d2text.Size = new System.Drawing.Size(36, 25);
            this.d2text.TabIndex = 32;
            this.d2text.TabStop = false;
            this.d2text.Text = "0";
            this.d2text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // d0text
            // 
            this.d0text.Location = new System.Drawing.Point(651, 49);
            this.d0text.Name = "d0text";
            this.d0text.ReadOnly = true;
            this.d0text.Size = new System.Drawing.Size(36, 25);
            this.d0text.TabIndex = 31;
            this.d0text.TabStop = false;
            this.d0text.Text = "0";
            this.d0text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // d3text
            // 
            this.d3text.Location = new System.Drawing.Point(390, 49);
            this.d3text.Name = "d3text";
            this.d3text.ReadOnly = true;
            this.d3text.Size = new System.Drawing.Size(36, 25);
            this.d3text.TabIndex = 30;
            this.d3text.TabStop = false;
            this.d3text.Text = "0";
            this.d3text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // d4text
            // 
            this.d4text.Location = new System.Drawing.Point(303, 49);
            this.d4text.Name = "d4text";
            this.d4text.ReadOnly = true;
            this.d4text.Size = new System.Drawing.Size(36, 25);
            this.d4text.TabIndex = 29;
            this.d4text.TabStop = false;
            this.d4text.Text = "0";
            this.d4text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // d5text
            // 
            this.d5text.Location = new System.Drawing.Point(216, 49);
            this.d5text.Name = "d5text";
            this.d5text.ReadOnly = true;
            this.d5text.Size = new System.Drawing.Size(36, 25);
            this.d5text.TabIndex = 28;
            this.d5text.TabStop = false;
            this.d5text.Text = "0";
            this.d5text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // d6text
            // 
            this.d6text.Location = new System.Drawing.Point(129, 49);
            this.d6text.Name = "d6text";
            this.d6text.ReadOnly = true;
            this.d6text.Size = new System.Drawing.Size(36, 25);
            this.d6text.TabIndex = 27;
            this.d6text.TabStop = false;
            this.d6text.Text = "0";
            this.d6text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // d7text
            // 
            this.d7text.Location = new System.Drawing.Point(42, 49);
            this.d7text.Name = "d7text";
            this.d7text.ReadOnly = true;
            this.d7text.Size = new System.Drawing.Size(36, 25);
            this.d7text.TabIndex = 26;
            this.d7text.TabStop = false;
            this.d7text.Text = "0";
            this.d7text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // c2text
            // 
            this.c2text.Location = new System.Drawing.Point(564, 21);
            this.c2text.Name = "c2text";
            this.c2text.ReadOnly = true;
            this.c2text.Size = new System.Drawing.Size(36, 25);
            this.c2text.TabIndex = 25;
            this.c2text.TabStop = false;
            this.c2text.Text = "0";
            this.c2text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // c3text
            // 
            this.c3text.Location = new System.Drawing.Point(477, 21);
            this.c3text.Name = "c3text";
            this.c3text.ReadOnly = true;
            this.c3text.Size = new System.Drawing.Size(36, 25);
            this.c3text.TabIndex = 24;
            this.c3text.TabStop = false;
            this.c3text.Text = "0";
            this.c3text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // c1text
            // 
            this.c1text.Location = new System.Drawing.Point(651, 21);
            this.c1text.Name = "c1text";
            this.c1text.ReadOnly = true;
            this.c1text.Size = new System.Drawing.Size(36, 25);
            this.c1text.TabIndex = 23;
            this.c1text.TabStop = false;
            this.c1text.Text = "0";
            this.c1text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // c4text
            // 
            this.c4text.Location = new System.Drawing.Point(390, 21);
            this.c4text.Name = "c4text";
            this.c4text.ReadOnly = true;
            this.c4text.Size = new System.Drawing.Size(36, 25);
            this.c4text.TabIndex = 22;
            this.c4text.TabStop = false;
            this.c4text.Text = "0";
            this.c4text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // c5text
            // 
            this.c5text.Location = new System.Drawing.Point(303, 21);
            this.c5text.Name = "c5text";
            this.c5text.ReadOnly = true;
            this.c5text.Size = new System.Drawing.Size(36, 25);
            this.c5text.TabIndex = 21;
            this.c5text.TabStop = false;
            this.c5text.Text = "0";
            this.c5text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // c6text
            // 
            this.c6text.Location = new System.Drawing.Point(216, 21);
            this.c6text.Name = "c6text";
            this.c6text.ReadOnly = true;
            this.c6text.Size = new System.Drawing.Size(36, 25);
            this.c6text.TabIndex = 20;
            this.c6text.TabStop = false;
            this.c6text.Text = "0";
            this.c6text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // c7text
            // 
            this.c7text.Location = new System.Drawing.Point(129, 21);
            this.c7text.Name = "c7text";
            this.c7text.ReadOnly = true;
            this.c7text.Size = new System.Drawing.Size(36, 25);
            this.c7text.TabIndex = 19;
            this.c7text.TabStop = false;
            this.c7text.Text = "0";
            this.c7text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // c8text
            // 
            this.c8text.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.c8text.Location = new System.Drawing.Point(42, 21);
            this.c8text.Name = "c8text";
            this.c8text.ReadOnly = true;
            this.c8text.Size = new System.Drawing.Size(36, 25);
            this.c8text.TabIndex = 18;
            this.c8text.TabStop = false;
            this.c8text.Text = "0";
            this.c8text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.c8text.WordWrap = false;
            // 
            // d1l
            // 
            this.d1l.AutoSize = true;
            this.d1l.Location = new System.Drawing.Point(526, 54);
            this.d1l.Name = "d1l";
            this.d1l.Size = new System.Drawing.Size(23, 15);
            this.d1l.TabIndex = 16;
            this.d1l.Text = "d1";
            // 
            // d0l
            // 
            this.d0l.AutoSize = true;
            this.d0l.Location = new System.Drawing.Point(612, 52);
            this.d0l.Name = "d0l";
            this.d0l.Size = new System.Drawing.Size(23, 15);
            this.d0l.TabIndex = 17;
            this.d0l.Text = "d0";
            // 
            // d2l
            // 
            this.d2l.AutoSize = true;
            this.d2l.Location = new System.Drawing.Point(440, 54);
            this.d2l.Name = "d2l";
            this.d2l.Size = new System.Drawing.Size(23, 15);
            this.d2l.TabIndex = 15;
            this.d2l.Text = "d2";
            // 
            // d7l
            // 
            this.d7l.AutoSize = true;
            this.d7l.Location = new System.Drawing.Point(10, 54);
            this.d7l.Name = "d7l";
            this.d7l.Size = new System.Drawing.Size(23, 15);
            this.d7l.TabIndex = 10;
            this.d7l.Text = "d7";
            // 
            // d3l
            // 
            this.d3l.AutoSize = true;
            this.d3l.Location = new System.Drawing.Point(354, 54);
            this.d3l.Name = "d3l";
            this.d3l.Size = new System.Drawing.Size(23, 15);
            this.d3l.TabIndex = 14;
            this.d3l.Text = "d3";
            // 
            // d6l
            // 
            this.d6l.AutoSize = true;
            this.d6l.Location = new System.Drawing.Point(96, 54);
            this.d6l.Name = "d6l";
            this.d6l.Size = new System.Drawing.Size(23, 15);
            this.d6l.TabIndex = 11;
            this.d6l.Text = "d6";
            // 
            // d4l
            // 
            this.d4l.AutoSize = true;
            this.d4l.Location = new System.Drawing.Point(268, 54);
            this.d4l.Name = "d4l";
            this.d4l.Size = new System.Drawing.Size(23, 15);
            this.d4l.TabIndex = 13;
            this.d4l.Text = "d4";
            // 
            // d5l
            // 
            this.d5l.AutoSize = true;
            this.d5l.Location = new System.Drawing.Point(182, 54);
            this.d5l.Name = "d5l";
            this.d5l.Size = new System.Drawing.Size(23, 15);
            this.d5l.TabIndex = 12;
            this.d5l.Text = "d5";
            // 
            // c2l
            // 
            this.c2l.AutoSize = true;
            this.c2l.Location = new System.Drawing.Point(526, 26);
            this.c2l.Name = "c2l";
            this.c2l.Size = new System.Drawing.Size(23, 15);
            this.c2l.TabIndex = 8;
            this.c2l.Text = "c2";
            // 
            // c1l
            // 
            this.c1l.AutoSize = true;
            this.c1l.Location = new System.Drawing.Point(612, 24);
            this.c1l.Name = "c1l";
            this.c1l.Size = new System.Drawing.Size(23, 15);
            this.c1l.TabIndex = 9;
            this.c1l.Text = "c1";
            // 
            // c3l
            // 
            this.c3l.AutoSize = true;
            this.c3l.Location = new System.Drawing.Point(440, 26);
            this.c3l.Name = "c3l";
            this.c3l.Size = new System.Drawing.Size(23, 15);
            this.c3l.TabIndex = 7;
            this.c3l.Text = "c3";
            // 
            // c8l
            // 
            this.c8l.AutoSize = true;
            this.c8l.Location = new System.Drawing.Point(10, 26);
            this.c8l.Name = "c8l";
            this.c8l.Size = new System.Drawing.Size(23, 15);
            this.c8l.TabIndex = 2;
            this.c8l.Text = "c8";
            // 
            // c4l
            // 
            this.c4l.AutoSize = true;
            this.c4l.Location = new System.Drawing.Point(354, 26);
            this.c4l.Name = "c4l";
            this.c4l.Size = new System.Drawing.Size(23, 15);
            this.c4l.TabIndex = 6;
            this.c4l.Text = "c4";
            // 
            // c7l
            // 
            this.c7l.AutoSize = true;
            this.c7l.Location = new System.Drawing.Point(96, 26);
            this.c7l.Name = "c7l";
            this.c7l.Size = new System.Drawing.Size(23, 15);
            this.c7l.TabIndex = 3;
            this.c7l.Text = "c7";
            // 
            // c5l
            // 
            this.c5l.AutoSize = true;
            this.c5l.Location = new System.Drawing.Point(268, 26);
            this.c5l.Name = "c5l";
            this.c5l.Size = new System.Drawing.Size(23, 15);
            this.c5l.TabIndex = 5;
            this.c5l.Text = "c5";
            // 
            // c6l
            // 
            this.c6l.AutoSize = true;
            this.c6l.Location = new System.Drawing.Point(182, 26);
            this.c6l.Name = "c6l";
            this.c6l.Size = new System.Drawing.Size(23, 15);
            this.c6l.TabIndex = 4;
            this.c6l.Text = "c6";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 416);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 35);
            this.button1.TabIndex = 35;
            this.button1.Text = "直接计算";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(101, 416);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 35);
            this.button2.TabIndex = 36;
            this.button2.Text = "分步计算";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(6, 206);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(514, 177);
            this.richTextBox1.TabIndex = 38;
            this.richTextBox1.Text = "被 加 数a            加    数b          \n本地进位D = a·b\n传送条件T = a + b\n进    位Cn = Dn + Tn·" +
    "Cn-1\n十 进 制dec          二 进 制bin";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 493);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.InputData);
            this.Controls.Add(this.Input);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Carry Lookahead Adder";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Input.ResumeLayout(false);
            this.Input.PerformLayout();
            this.InputData.ResumeLayout(false);
            this.InputData.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox Input;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Num2dec;
        private System.Windows.Forms.TextBox Num1dec;
        private System.Windows.Forms.GroupBox InputData;
        private System.Windows.Forms.Label a1l;
        private System.Windows.Forms.Label a0l;
        private System.Windows.Forms.Label a2l;
        private System.Windows.Forms.Label a7l;
        private System.Windows.Forms.Label a3l;
        private System.Windows.Forms.Label a6l;
        private System.Windows.Forms.Label a4l;
        private System.Windows.Forms.Label a5l;
        private System.Windows.Forms.Label b1l;
        private System.Windows.Forms.Label b0l;
        private System.Windows.Forms.Label b2l;
        private System.Windows.Forms.Label b7l;
        private System.Windows.Forms.Label b3l;
        private System.Windows.Forms.Label b6l;
        private System.Windows.Forms.Label b4l;
        private System.Windows.Forms.Label b5l;
        private System.Windows.Forms.TextBox b1text;
        private System.Windows.Forms.TextBox b2text;
        private System.Windows.Forms.TextBox b0text;
        private System.Windows.Forms.TextBox b3text;
        private System.Windows.Forms.TextBox b4text;
        private System.Windows.Forms.TextBox b5text;
        private System.Windows.Forms.TextBox b6text;
        private System.Windows.Forms.TextBox b7text;
        private System.Windows.Forms.TextBox a1text;
        private System.Windows.Forms.TextBox a2text;
        private System.Windows.Forms.TextBox a0text;
        private System.Windows.Forms.TextBox a3text;
        private System.Windows.Forms.TextBox a4text;
        private System.Windows.Forms.TextBox a5text;
        private System.Windows.Forms.TextBox a6text;
        private System.Windows.Forms.TextBox a7text;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox d1text;
        private System.Windows.Forms.TextBox d2text;
        private System.Windows.Forms.TextBox d0text;
        private System.Windows.Forms.TextBox d3text;
        private System.Windows.Forms.TextBox d4text;
        private System.Windows.Forms.TextBox d5text;
        private System.Windows.Forms.TextBox d6text;
        private System.Windows.Forms.TextBox d7text;
        private System.Windows.Forms.TextBox c2text;
        private System.Windows.Forms.TextBox c3text;
        private System.Windows.Forms.TextBox c1text;
        private System.Windows.Forms.TextBox c4text;
        private System.Windows.Forms.TextBox c5text;
        private System.Windows.Forms.TextBox c6text;
        private System.Windows.Forms.TextBox c7text;
        private System.Windows.Forms.TextBox c8text;
        private System.Windows.Forms.Label d1l;
        private System.Windows.Forms.Label d0l;
        private System.Windows.Forms.Label d2l;
        private System.Windows.Forms.Label d7l;
        private System.Windows.Forms.Label d3l;
        private System.Windows.Forms.Label d6l;
        private System.Windows.Forms.Label d4l;
        private System.Windows.Forms.Label d5l;
        private System.Windows.Forms.Label c2l;
        private System.Windows.Forms.Label c1l;
        private System.Windows.Forms.Label c3l;
        private System.Windows.Forms.Label c8l;
        private System.Windows.Forms.Label c4l;
        private System.Windows.Forms.Label c7l;
        private System.Windows.Forms.Label c5l;
        private System.Windows.Forms.Label c6l;
        private System.Windows.Forms.TextBox Num2bin;
        private System.Windows.Forms.TextBox Num1bin;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox t1text;
        private System.Windows.Forms.TextBox t2text;
        private System.Windows.Forms.TextBox t0text;
        private System.Windows.Forms.TextBox t3text;
        private System.Windows.Forms.TextBox t4text;
        private System.Windows.Forms.TextBox t5text;
        private System.Windows.Forms.TextBox t6text;
        private System.Windows.Forms.TextBox t7text;
        private System.Windows.Forms.Label t1l;
        private System.Windows.Forms.Label t0l;
        private System.Windows.Forms.Label t2l;
        private System.Windows.Forms.Label t7l;
        private System.Windows.Forms.Label t3l;
        private System.Windows.Forms.Label t6l;
        private System.Windows.Forms.Label t4l;
        private System.Windows.Forms.Label t5l;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox AnswerBin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox AnswerDec;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

