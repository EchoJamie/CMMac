﻿namespace ComputerModelMachine
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.GBRegister = new System.Windows.Forms.GroupBox();
            this.Textbox_R7 = new System.Windows.Forms.TextBox();
            this.Textbox_R6 = new System.Windows.Forms.TextBox();
            this.Textbox_R5 = new System.Windows.Forms.TextBox();
            this.Textbox_R4 = new System.Windows.Forms.TextBox();
            this.Label_R7 = new System.Windows.Forms.Label();
            this.Label_R6 = new System.Windows.Forms.Label();
            this.Label_R5 = new System.Windows.Forms.Label();
            this.Label_R4 = new System.Windows.Forms.Label();
            this.Textbox_R3 = new System.Windows.Forms.TextBox();
            this.Textbox_R2 = new System.Windows.Forms.TextBox();
            this.Textbox_R1 = new System.Windows.Forms.TextBox();
            this.Textbox_R0 = new System.Windows.Forms.TextBox();
            this.Label_R3 = new System.Windows.Forms.Label();
            this.Label_R2 = new System.Windows.Forms.Label();
            this.Label_R1 = new System.Windows.Forms.Label();
            this.Label_R0 = new System.Windows.Forms.Label();
            this.GBRigesterOther = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Textbox_PSW = new System.Windows.Forms.TextBox();
            this.Label_PSW = new System.Windows.Forms.Label();
            this.Textbox_IMDR = new System.Windows.Forms.TextBox();
            this.Textbox_IMAR = new System.Windows.Forms.TextBox();
            this.Textbox_MDR = new System.Windows.Forms.TextBox();
            this.Textbox_IR = new System.Windows.Forms.TextBox();
            this.Label_IMDR = new System.Windows.Forms.Label();
            this.Label_IMAR = new System.Windows.Forms.Label();
            this.Label_MDR = new System.Windows.Forms.Label();
            this.Label_IR = new System.Windows.Forms.Label();
            this.Textbox_DR = new System.Windows.Forms.TextBox();
            this.Textbox_MAR = new System.Windows.Forms.TextBox();
            this.Label_MAR = new System.Windows.Forms.Label();
            this.Textbox_SR = new System.Windows.Forms.TextBox();
            this.Textbox_PC = new System.Windows.Forms.TextBox();
            this.Label_DR = new System.Windows.Forms.Label();
            this.Label_SR = new System.Windows.Forms.Label();
            this.Label_PC = new System.Windows.Forms.Label();
            this.GBAssembly = new System.Windows.Forms.GroupBox();
            this.Listbox_Code = new System.Windows.Forms.ListBox();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.btn_InputFile = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.GB_DMU = new System.Windows.Forms.GroupBox();
            this.Listview_DataMemory = new System.Windows.Forms.ListView();
            this.GB_MicroOrder = new System.Windows.Forms.GroupBox();
            this.Listbox_MicroOrder = new System.Windows.Forms.ListBox();
            this.btn_Start = new System.Windows.Forms.Button();
            this.GB_OMU = new System.Windows.Forms.GroupBox();
            this.Listview_OrderMemory = new System.Windows.Forms.ListView();
            this.ColumnHeader_Name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnHeader_Code = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.GB_MC = new System.Windows.Forms.GroupBox();
            this.Listbox_MachineCode = new System.Windows.Forms.ListBox();
            this.btn_EveyStep = new System.Windows.Forms.Button();
            this.GB_Time = new System.Windows.Forms.GroupBox();
            this.Listbox_Time = new System.Windows.Forms.ListBox();
            this.btn_OpenCLA = new System.Windows.Forms.Button();
            this.GB_PrivateInfo = new System.Windows.Forms.GroupBox();
            this.RTB_PriInfo = new System.Windows.Forms.RichTextBox();
            this.GBRegister.SuspendLayout();
            this.GBRigesterOther.SuspendLayout();
            this.GBAssembly.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.GB_DMU.SuspendLayout();
            this.GB_MicroOrder.SuspendLayout();
            this.GB_OMU.SuspendLayout();
            this.GB_MC.SuspendLayout();
            this.GB_Time.SuspendLayout();
            this.GB_PrivateInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // GBRegister
            // 
            this.GBRegister.BackColor = System.Drawing.SystemColors.Control;
            this.GBRegister.Controls.Add(this.Textbox_R7);
            this.GBRegister.Controls.Add(this.Textbox_R6);
            this.GBRegister.Controls.Add(this.Textbox_R5);
            this.GBRegister.Controls.Add(this.Textbox_R4);
            this.GBRegister.Controls.Add(this.Label_R7);
            this.GBRegister.Controls.Add(this.Label_R6);
            this.GBRegister.Controls.Add(this.Label_R5);
            this.GBRegister.Controls.Add(this.Label_R4);
            this.GBRegister.Controls.Add(this.Textbox_R3);
            this.GBRegister.Controls.Add(this.Textbox_R2);
            this.GBRegister.Controls.Add(this.Textbox_R1);
            this.GBRegister.Controls.Add(this.Textbox_R0);
            this.GBRegister.Controls.Add(this.Label_R3);
            this.GBRegister.Controls.Add(this.Label_R2);
            this.GBRegister.Controls.Add(this.Label_R1);
            this.GBRegister.Controls.Add(this.Label_R0);
            this.GBRegister.Location = new System.Drawing.Point(3, 2);
            this.GBRegister.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GBRegister.Name = "GBRegister";
            this.GBRegister.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GBRegister.Size = new System.Drawing.Size(205, 151);
            this.GBRegister.TabIndex = 0;
            this.GBRegister.TabStop = false;
            this.GBRegister.Text = "通用寄存器组";
            // 
            // Textbox_R7
            // 
            this.Textbox_R7.Location = new System.Drawing.Point(137, 111);
            this.Textbox_R7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_R7.Name = "Textbox_R7";
            this.Textbox_R7.ReadOnly = true;
            this.Textbox_R7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_R7.ShortcutsEnabled = false;
            this.Textbox_R7.Size = new System.Drawing.Size(53, 25);
            this.Textbox_R7.TabIndex = 15;
            this.Textbox_R7.TabStop = false;
            this.Textbox_R7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_R7.WordWrap = false;
            // 
            // Textbox_R6
            // 
            this.Textbox_R6.Location = new System.Drawing.Point(137, 80);
            this.Textbox_R6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_R6.Name = "Textbox_R6";
            this.Textbox_R6.ReadOnly = true;
            this.Textbox_R6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_R6.ShortcutsEnabled = false;
            this.Textbox_R6.Size = new System.Drawing.Size(53, 25);
            this.Textbox_R6.TabIndex = 14;
            this.Textbox_R6.TabStop = false;
            this.Textbox_R6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_R6.WordWrap = false;
            // 
            // Textbox_R5
            // 
            this.Textbox_R5.Location = new System.Drawing.Point(137, 49);
            this.Textbox_R5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_R5.Name = "Textbox_R5";
            this.Textbox_R5.ReadOnly = true;
            this.Textbox_R5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_R5.ShortcutsEnabled = false;
            this.Textbox_R5.Size = new System.Drawing.Size(53, 25);
            this.Textbox_R5.TabIndex = 13;
            this.Textbox_R5.TabStop = false;
            this.Textbox_R5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_R5.WordWrap = false;
            // 
            // Textbox_R4
            // 
            this.Textbox_R4.Location = new System.Drawing.Point(137, 18);
            this.Textbox_R4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_R4.Name = "Textbox_R4";
            this.Textbox_R4.ReadOnly = true;
            this.Textbox_R4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_R4.ShortcutsEnabled = false;
            this.Textbox_R4.Size = new System.Drawing.Size(53, 25);
            this.Textbox_R4.TabIndex = 8;
            this.Textbox_R4.TabStop = false;
            this.Textbox_R4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_R4.WordWrap = false;
            // 
            // Label_R7
            // 
            this.Label_R7.AutoSize = true;
            this.Label_R7.Location = new System.Drawing.Point(109, 114);
            this.Label_R7.Name = "Label_R7";
            this.Label_R7.Size = new System.Drawing.Size(23, 15);
            this.Label_R7.TabIndex = 12;
            this.Label_R7.Text = "R7";
            // 
            // Label_R6
            // 
            this.Label_R6.AutoSize = true;
            this.Label_R6.Location = new System.Drawing.Point(109, 82);
            this.Label_R6.Name = "Label_R6";
            this.Label_R6.Size = new System.Drawing.Size(23, 15);
            this.Label_R6.TabIndex = 11;
            this.Label_R6.Text = "R6";
            // 
            // Label_R5
            // 
            this.Label_R5.AutoSize = true;
            this.Label_R5.Location = new System.Drawing.Point(109, 52);
            this.Label_R5.Name = "Label_R5";
            this.Label_R5.Size = new System.Drawing.Size(23, 15);
            this.Label_R5.TabIndex = 10;
            this.Label_R5.Text = "R5";
            // 
            // Label_R4
            // 
            this.Label_R4.AutoSize = true;
            this.Label_R4.Location = new System.Drawing.Point(109, 21);
            this.Label_R4.Name = "Label_R4";
            this.Label_R4.Size = new System.Drawing.Size(23, 15);
            this.Label_R4.TabIndex = 9;
            this.Label_R4.Text = "R4";
            // 
            // Textbox_R3
            // 
            this.Textbox_R3.Location = new System.Drawing.Point(40, 111);
            this.Textbox_R3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_R3.Name = "Textbox_R3";
            this.Textbox_R3.ReadOnly = true;
            this.Textbox_R3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_R3.ShortcutsEnabled = false;
            this.Textbox_R3.Size = new System.Drawing.Size(53, 25);
            this.Textbox_R3.TabIndex = 7;
            this.Textbox_R3.TabStop = false;
            this.Textbox_R3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_R3.WordWrap = false;
            // 
            // Textbox_R2
            // 
            this.Textbox_R2.Location = new System.Drawing.Point(40, 80);
            this.Textbox_R2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_R2.Name = "Textbox_R2";
            this.Textbox_R2.ReadOnly = true;
            this.Textbox_R2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_R2.ShortcutsEnabled = false;
            this.Textbox_R2.Size = new System.Drawing.Size(53, 25);
            this.Textbox_R2.TabIndex = 6;
            this.Textbox_R2.TabStop = false;
            this.Textbox_R2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_R2.WordWrap = false;
            // 
            // Textbox_R1
            // 
            this.Textbox_R1.Location = new System.Drawing.Point(40, 49);
            this.Textbox_R1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_R1.Name = "Textbox_R1";
            this.Textbox_R1.ReadOnly = true;
            this.Textbox_R1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_R1.ShortcutsEnabled = false;
            this.Textbox_R1.Size = new System.Drawing.Size(53, 25);
            this.Textbox_R1.TabIndex = 5;
            this.Textbox_R1.TabStop = false;
            this.Textbox_R1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_R1.WordWrap = false;
            // 
            // Textbox_R0
            // 
            this.Textbox_R0.Location = new System.Drawing.Point(40, 18);
            this.Textbox_R0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_R0.Name = "Textbox_R0";
            this.Textbox_R0.ReadOnly = true;
            this.Textbox_R0.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_R0.ShortcutsEnabled = false;
            this.Textbox_R0.Size = new System.Drawing.Size(53, 25);
            this.Textbox_R0.TabIndex = 1;
            this.Textbox_R0.TabStop = false;
            this.Textbox_R0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_R0.WordWrap = false;
            // 
            // Label_R3
            // 
            this.Label_R3.AutoSize = true;
            this.Label_R3.Location = new System.Drawing.Point(12, 114);
            this.Label_R3.Name = "Label_R3";
            this.Label_R3.Size = new System.Drawing.Size(23, 15);
            this.Label_R3.TabIndex = 4;
            this.Label_R3.Text = "R3";
            // 
            // Label_R2
            // 
            this.Label_R2.AutoSize = true;
            this.Label_R2.Location = new System.Drawing.Point(12, 82);
            this.Label_R2.Name = "Label_R2";
            this.Label_R2.Size = new System.Drawing.Size(23, 15);
            this.Label_R2.TabIndex = 3;
            this.Label_R2.Text = "R2";
            // 
            // Label_R1
            // 
            this.Label_R1.AutoSize = true;
            this.Label_R1.Location = new System.Drawing.Point(12, 52);
            this.Label_R1.Name = "Label_R1";
            this.Label_R1.Size = new System.Drawing.Size(23, 15);
            this.Label_R1.TabIndex = 2;
            this.Label_R1.Text = "R1";
            // 
            // Label_R0
            // 
            this.Label_R0.AutoSize = true;
            this.Label_R0.Location = new System.Drawing.Point(12, 21);
            this.Label_R0.Name = "Label_R0";
            this.Label_R0.Size = new System.Drawing.Size(23, 15);
            this.Label_R0.TabIndex = 1;
            this.Label_R0.Text = "R0";
            // 
            // GBRigesterOther
            // 
            this.GBRigesterOther.BackColor = System.Drawing.SystemColors.Control;
            this.GBRigesterOther.Controls.Add(this.label3);
            this.GBRigesterOther.Controls.Add(this.Textbox_PSW);
            this.GBRigesterOther.Controls.Add(this.Label_PSW);
            this.GBRigesterOther.Controls.Add(this.Textbox_IMDR);
            this.GBRigesterOther.Controls.Add(this.Textbox_IMAR);
            this.GBRigesterOther.Controls.Add(this.Textbox_MDR);
            this.GBRigesterOther.Controls.Add(this.Textbox_IR);
            this.GBRigesterOther.Controls.Add(this.Label_IMDR);
            this.GBRigesterOther.Controls.Add(this.Label_IMAR);
            this.GBRigesterOther.Controls.Add(this.Label_MDR);
            this.GBRigesterOther.Controls.Add(this.Label_IR);
            this.GBRigesterOther.Controls.Add(this.Textbox_DR);
            this.GBRigesterOther.Controls.Add(this.Textbox_MAR);
            this.GBRigesterOther.Controls.Add(this.Label_MAR);
            this.GBRigesterOther.Controls.Add(this.Textbox_SR);
            this.GBRigesterOther.Controls.Add(this.Textbox_PC);
            this.GBRigesterOther.Controls.Add(this.Label_DR);
            this.GBRigesterOther.Controls.Add(this.Label_SR);
            this.GBRigesterOther.Controls.Add(this.Label_PC);
            this.GBRigesterOther.Location = new System.Drawing.Point(3, 160);
            this.GBRigesterOther.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GBRigesterOther.Name = "GBRigesterOther";
            this.GBRigesterOther.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GBRigesterOther.Size = new System.Drawing.Size(205, 205);
            this.GBRigesterOther.TabIndex = 16;
            this.GBRigesterOther.TabStop = false;
            this.GBRigesterOther.Text = "基本寄存器组";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 15);
            this.label3.TabIndex = 18;
            this.label3.Text = "    H S V N Z C";
            // 
            // Textbox_PSW
            // 
            this.Textbox_PSW.Location = new System.Drawing.Point(40, 142);
            this.Textbox_PSW.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_PSW.Name = "Textbox_PSW";
            this.Textbox_PSW.ReadOnly = true;
            this.Textbox_PSW.ShortcutsEnabled = false;
            this.Textbox_PSW.Size = new System.Drawing.Size(151, 25);
            this.Textbox_PSW.TabIndex = 17;
            this.Textbox_PSW.TabStop = false;
            this.Textbox_PSW.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_PSW.WordWrap = false;
            // 
            // Label_PSW
            // 
            this.Label_PSW.AutoSize = true;
            this.Label_PSW.Location = new System.Drawing.Point(8, 145);
            this.Label_PSW.Name = "Label_PSW";
            this.Label_PSW.Size = new System.Drawing.Size(31, 15);
            this.Label_PSW.TabIndex = 16;
            this.Label_PSW.Text = "PSW";
            // 
            // Textbox_IMDR
            // 
            this.Textbox_IMDR.Location = new System.Drawing.Point(138, 111);
            this.Textbox_IMDR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_IMDR.Name = "Textbox_IMDR";
            this.Textbox_IMDR.ReadOnly = true;
            this.Textbox_IMDR.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_IMDR.ShortcutsEnabled = false;
            this.Textbox_IMDR.Size = new System.Drawing.Size(53, 25);
            this.Textbox_IMDR.TabIndex = 15;
            this.Textbox_IMDR.TabStop = false;
            this.Textbox_IMDR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_IMDR.WordWrap = false;
            // 
            // Textbox_IMAR
            // 
            this.Textbox_IMAR.Location = new System.Drawing.Point(138, 80);
            this.Textbox_IMAR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_IMAR.Name = "Textbox_IMAR";
            this.Textbox_IMAR.ReadOnly = true;
            this.Textbox_IMAR.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_IMAR.ShortcutsEnabled = false;
            this.Textbox_IMAR.Size = new System.Drawing.Size(53, 25);
            this.Textbox_IMAR.TabIndex = 14;
            this.Textbox_IMAR.TabStop = false;
            this.Textbox_IMAR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_IMAR.WordWrap = false;
            // 
            // Textbox_MDR
            // 
            this.Textbox_MDR.Location = new System.Drawing.Point(138, 49);
            this.Textbox_MDR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_MDR.Name = "Textbox_MDR";
            this.Textbox_MDR.ReadOnly = true;
            this.Textbox_MDR.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_MDR.ShortcutsEnabled = false;
            this.Textbox_MDR.Size = new System.Drawing.Size(53, 25);
            this.Textbox_MDR.TabIndex = 13;
            this.Textbox_MDR.TabStop = false;
            this.Textbox_MDR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_MDR.WordWrap = false;
            // 
            // Textbox_IR
            // 
            this.Textbox_IR.Location = new System.Drawing.Point(40, 49);
            this.Textbox_IR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_IR.Name = "Textbox_IR";
            this.Textbox_IR.ReadOnly = true;
            this.Textbox_IR.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_IR.ShortcutsEnabled = false;
            this.Textbox_IR.Size = new System.Drawing.Size(53, 25);
            this.Textbox_IR.TabIndex = 8;
            this.Textbox_IR.TabStop = false;
            this.Textbox_IR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_IR.WordWrap = false;
            // 
            // Label_IMDR
            // 
            this.Label_IMDR.AutoSize = true;
            this.Label_IMDR.Location = new System.Drawing.Point(101, 114);
            this.Label_IMDR.Name = "Label_IMDR";
            this.Label_IMDR.Size = new System.Drawing.Size(39, 15);
            this.Label_IMDR.TabIndex = 12;
            this.Label_IMDR.Text = "IMDR";
            // 
            // Label_IMAR
            // 
            this.Label_IMAR.AutoSize = true;
            this.Label_IMAR.Location = new System.Drawing.Point(101, 83);
            this.Label_IMAR.Name = "Label_IMAR";
            this.Label_IMAR.Size = new System.Drawing.Size(39, 15);
            this.Label_IMAR.TabIndex = 11;
            this.Label_IMAR.Text = "IMAR";
            // 
            // Label_MDR
            // 
            this.Label_MDR.AutoSize = true;
            this.Label_MDR.Location = new System.Drawing.Point(101, 52);
            this.Label_MDR.Name = "Label_MDR";
            this.Label_MDR.Size = new System.Drawing.Size(31, 15);
            this.Label_MDR.TabIndex = 10;
            this.Label_MDR.Text = "MDR";
            // 
            // Label_IR
            // 
            this.Label_IR.AutoSize = true;
            this.Label_IR.Location = new System.Drawing.Point(8, 52);
            this.Label_IR.Name = "Label_IR";
            this.Label_IR.Size = new System.Drawing.Size(23, 15);
            this.Label_IR.TabIndex = 9;
            this.Label_IR.Text = "IR";
            // 
            // Textbox_DR
            // 
            this.Textbox_DR.Location = new System.Drawing.Point(40, 111);
            this.Textbox_DR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_DR.Name = "Textbox_DR";
            this.Textbox_DR.ReadOnly = true;
            this.Textbox_DR.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_DR.ShortcutsEnabled = false;
            this.Textbox_DR.Size = new System.Drawing.Size(53, 25);
            this.Textbox_DR.TabIndex = 7;
            this.Textbox_DR.TabStop = false;
            this.Textbox_DR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_DR.WordWrap = false;
            // 
            // Textbox_MAR
            // 
            this.Textbox_MAR.Location = new System.Drawing.Point(138, 18);
            this.Textbox_MAR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_MAR.Name = "Textbox_MAR";
            this.Textbox_MAR.ReadOnly = true;
            this.Textbox_MAR.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_MAR.ShortcutsEnabled = false;
            this.Textbox_MAR.Size = new System.Drawing.Size(53, 25);
            this.Textbox_MAR.TabIndex = 5;
            this.Textbox_MAR.TabStop = false;
            this.Textbox_MAR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_MAR.WordWrap = false;
            // 
            // Label_MAR
            // 
            this.Label_MAR.AutoSize = true;
            this.Label_MAR.Location = new System.Drawing.Point(101, 21);
            this.Label_MAR.Name = "Label_MAR";
            this.Label_MAR.Size = new System.Drawing.Size(31, 15);
            this.Label_MAR.TabIndex = 2;
            this.Label_MAR.Text = "MAR";
            // 
            // Textbox_SR
            // 
            this.Textbox_SR.Location = new System.Drawing.Point(40, 80);
            this.Textbox_SR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_SR.Name = "Textbox_SR";
            this.Textbox_SR.ReadOnly = true;
            this.Textbox_SR.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_SR.ShortcutsEnabled = false;
            this.Textbox_SR.Size = new System.Drawing.Size(53, 25);
            this.Textbox_SR.TabIndex = 6;
            this.Textbox_SR.TabStop = false;
            this.Textbox_SR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_SR.WordWrap = false;
            // 
            // Textbox_PC
            // 
            this.Textbox_PC.Location = new System.Drawing.Point(40, 18);
            this.Textbox_PC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Textbox_PC.Name = "Textbox_PC";
            this.Textbox_PC.ReadOnly = true;
            this.Textbox_PC.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Textbox_PC.ShortcutsEnabled = false;
            this.Textbox_PC.Size = new System.Drawing.Size(53, 25);
            this.Textbox_PC.TabIndex = 1;
            this.Textbox_PC.TabStop = false;
            this.Textbox_PC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Textbox_PC.WordWrap = false;
            // 
            // Label_DR
            // 
            this.Label_DR.AutoSize = true;
            this.Label_DR.Location = new System.Drawing.Point(8, 114);
            this.Label_DR.Name = "Label_DR";
            this.Label_DR.Size = new System.Drawing.Size(23, 15);
            this.Label_DR.TabIndex = 4;
            this.Label_DR.Text = "DR";
            // 
            // Label_SR
            // 
            this.Label_SR.AutoSize = true;
            this.Label_SR.Location = new System.Drawing.Point(8, 83);
            this.Label_SR.Name = "Label_SR";
            this.Label_SR.Size = new System.Drawing.Size(23, 15);
            this.Label_SR.TabIndex = 3;
            this.Label_SR.Text = "SR";
            // 
            // Label_PC
            // 
            this.Label_PC.AutoSize = true;
            this.Label_PC.Location = new System.Drawing.Point(8, 21);
            this.Label_PC.Name = "Label_PC";
            this.Label_PC.Size = new System.Drawing.Size(23, 15);
            this.Label_PC.TabIndex = 1;
            this.Label_PC.Text = "PC";
            // 
            // GBAssembly
            // 
            this.GBAssembly.Controls.Add(this.Listbox_Code);
            this.GBAssembly.Location = new System.Drawing.Point(213, 2);
            this.GBAssembly.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GBAssembly.Name = "GBAssembly";
            this.GBAssembly.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GBAssembly.Size = new System.Drawing.Size(219, 362);
            this.GBAssembly.TabIndex = 18;
            this.GBAssembly.TabStop = false;
            this.GBAssembly.Text = "汇编指令";
            // 
            // Listbox_Code
            // 
            this.Listbox_Code.FormattingEnabled = true;
            this.Listbox_Code.ItemHeight = 15;
            this.Listbox_Code.Location = new System.Drawing.Point(7, 20);
            this.Listbox_Code.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Listbox_Code.Name = "Listbox_Code";
            this.Listbox_Code.Size = new System.Drawing.Size(205, 334);
            this.Listbox_Code.TabIndex = 0;
            // 
            // btn_Reset
            // 
            this.btn_Reset.Location = new System.Drawing.Point(1279, 758);
            this.btn_Reset.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(99, 34);
            this.btn_Reset.TabIndex = 20;
            this.btn_Reset.Text = "清零";
            this.btn_Reset.UseVisualStyleBackColor = true;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // btn_InputFile
            // 
            this.btn_InputFile.Location = new System.Drawing.Point(1153, 758);
            this.btn_InputFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_InputFile.Name = "btn_InputFile";
            this.btn_InputFile.Size = new System.Drawing.Size(99, 34);
            this.btn_InputFile.TabIndex = 21;
            this.btn_InputFile.Text = "导入文件";
            this.btn_InputFile.UseVisualStyleBackColor = true;
            this.btn_InputFile.Click += new System.EventHandler(this.btn_InputFile_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(919, 178);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(580, 562);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // GB_DMU
            // 
            this.GB_DMU.Controls.Add(this.Listview_DataMemory);
            this.GB_DMU.Location = new System.Drawing.Point(438, 369);
            this.GB_DMU.Name = "GB_DMU";
            this.GB_DMU.Size = new System.Drawing.Size(200, 431);
            this.GB_DMU.TabIndex = 23;
            this.GB_DMU.TabStop = false;
            this.GB_DMU.Text = "数据存储单元";
            // 
            // Listview_DataMemory
            // 
            this.Listview_DataMemory.GridLines = true;
            this.Listview_DataMemory.HideSelection = false;
            this.Listview_DataMemory.Location = new System.Drawing.Point(6, 18);
            this.Listview_DataMemory.Name = "Listview_DataMemory";
            this.Listview_DataMemory.Size = new System.Drawing.Size(187, 405);
            this.Listview_DataMemory.TabIndex = 0;
            this.Listview_DataMemory.UseCompatibleStateImageBehavior = false;
            this.Listview_DataMemory.View = System.Windows.Forms.View.Details;
            // 
            // GB_MicroOrder
            // 
            this.GB_MicroOrder.Controls.Add(this.Listbox_MicroOrder);
            this.GB_MicroOrder.Location = new System.Drawing.Point(3, 369);
            this.GB_MicroOrder.Name = "GB_MicroOrder";
            this.GB_MicroOrder.Size = new System.Drawing.Size(429, 431);
            this.GB_MicroOrder.TabIndex = 24;
            this.GB_MicroOrder.TabStop = false;
            this.GB_MicroOrder.Text = "微指令序列记录";
            // 
            // Listbox_MicroOrder
            // 
            this.Listbox_MicroOrder.FormattingEnabled = true;
            this.Listbox_MicroOrder.ItemHeight = 15;
            this.Listbox_MicroOrder.Location = new System.Drawing.Point(7, 20);
            this.Listbox_MicroOrder.Name = "Listbox_MicroOrder";
            this.Listbox_MicroOrder.Size = new System.Drawing.Size(415, 394);
            this.Listbox_MicroOrder.TabIndex = 0;
            // 
            // btn_Start
            // 
            this.btn_Start.Location = new System.Drawing.Point(910, 758);
            this.btn_Start.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Start.Name = "btn_Start";
            this.btn_Start.Size = new System.Drawing.Size(99, 34);
            this.btn_Start.TabIndex = 25;
            this.btn_Start.Text = "开始执行";
            this.btn_Start.UseVisualStyleBackColor = true;
            this.btn_Start.Click += new System.EventHandler(this.btn_Start_Click);
            // 
            // GB_OMU
            // 
            this.GB_OMU.Controls.Add(this.Listview_OrderMemory);
            this.GB_OMU.Location = new System.Drawing.Point(644, 369);
            this.GB_OMU.Name = "GB_OMU";
            this.GB_OMU.Size = new System.Drawing.Size(247, 431);
            this.GB_OMU.TabIndex = 24;
            this.GB_OMU.TabStop = false;
            this.GB_OMU.Text = "指令存储单元";
            // 
            // Listview_OrderMemory
            // 
            this.Listview_OrderMemory.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ColumnHeader_Name,
            this.ColumnHeader_Code});
            this.Listview_OrderMemory.GridLines = true;
            this.Listview_OrderMemory.HideSelection = false;
            this.Listview_OrderMemory.Location = new System.Drawing.Point(6, 18);
            this.Listview_OrderMemory.Name = "Listview_OrderMemory";
            this.Listview_OrderMemory.ShowGroups = false;
            this.Listview_OrderMemory.Size = new System.Drawing.Size(235, 405);
            this.Listview_OrderMemory.TabIndex = 0;
            this.Listview_OrderMemory.TabStop = false;
            this.Listview_OrderMemory.UseCompatibleStateImageBehavior = false;
            this.Listview_OrderMemory.View = System.Windows.Forms.View.Details;
            // 
            // ColumnHeader_Name
            // 
            this.ColumnHeader_Name.Text = "IAD";
            this.ColumnHeader_Name.Width = 45;
            // 
            // ColumnHeader_Code
            // 
            this.ColumnHeader_Code.Text = "IValue";
            this.ColumnHeader_Code.Width = 125;
            // 
            // GB_MC
            // 
            this.GB_MC.Controls.Add(this.Listbox_MachineCode);
            this.GB_MC.Location = new System.Drawing.Point(438, 2);
            this.GB_MC.Name = "GB_MC";
            this.GB_MC.Size = new System.Drawing.Size(200, 363);
            this.GB_MC.TabIndex = 25;
            this.GB_MC.TabStop = false;
            this.GB_MC.Text = "机器码";
            // 
            // Listbox_MachineCode
            // 
            this.Listbox_MachineCode.FormattingEnabled = true;
            this.Listbox_MachineCode.ItemHeight = 15;
            this.Listbox_MachineCode.Location = new System.Drawing.Point(7, 20);
            this.Listbox_MachineCode.Name = "Listbox_MachineCode";
            this.Listbox_MachineCode.Size = new System.Drawing.Size(187, 334);
            this.Listbox_MachineCode.TabIndex = 0;
            // 
            // btn_EveyStep
            // 
            this.btn_EveyStep.Location = new System.Drawing.Point(1027, 758);
            this.btn_EveyStep.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_EveyStep.Name = "btn_EveyStep";
            this.btn_EveyStep.Size = new System.Drawing.Size(99, 34);
            this.btn_EveyStep.TabIndex = 26;
            this.btn_EveyStep.Text = "单步执行";
            this.btn_EveyStep.UseVisualStyleBackColor = true;
            this.btn_EveyStep.Click += new System.EventHandler(this.btn_EveyStep_Click);
            // 
            // GB_Time
            // 
            this.GB_Time.Controls.Add(this.Listbox_Time);
            this.GB_Time.Location = new System.Drawing.Point(919, 2);
            this.GB_Time.Name = "GB_Time";
            this.GB_Time.Size = new System.Drawing.Size(223, 170);
            this.GB_Time.TabIndex = 27;
            this.GB_Time.TabStop = false;
            this.GB_Time.Text = "指令周期";
            // 
            // Listbox_Time
            // 
            this.Listbox_Time.Font = new System.Drawing.Font("宋体", 15F);
            this.Listbox_Time.FormattingEnabled = true;
            this.Listbox_Time.ItemHeight = 25;
            this.Listbox_Time.Items.AddRange(new object[] {
            "FT",
            "ST",
            "DT",
            "ET"});
            this.Listbox_Time.Location = new System.Drawing.Point(14, 22);
            this.Listbox_Time.Name = "Listbox_Time";
            this.Listbox_Time.Size = new System.Drawing.Size(196, 129);
            this.Listbox_Time.TabIndex = 0;
            // 
            // btn_OpenCLA
            // 
            this.btn_OpenCLA.Location = new System.Drawing.Point(1392, 759);
            this.btn_OpenCLA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_OpenCLA.Name = "btn_OpenCLA";
            this.btn_OpenCLA.Size = new System.Drawing.Size(135, 34);
            this.btn_OpenCLA.TabIndex = 28;
            this.btn_OpenCLA.Text = "超前进位加法器";
            this.btn_OpenCLA.UseVisualStyleBackColor = true;
            this.btn_OpenCLA.Visible = false;
            this.btn_OpenCLA.Click += new System.EventHandler(this.btn_OpenCLA_Click);
            // 
            // GB_PrivateInfo
            // 
            this.GB_PrivateInfo.Controls.Add(this.RTB_PriInfo);
            this.GB_PrivateInfo.Location = new System.Drawing.Point(1186, 2);
            this.GB_PrivateInfo.Name = "GB_PrivateInfo";
            this.GB_PrivateInfo.Size = new System.Drawing.Size(313, 170);
            this.GB_PrivateInfo.TabIndex = 29;
            this.GB_PrivateInfo.TabStop = false;
            this.GB_PrivateInfo.Text = "作者信息";
            // 
            // RTB_PriInfo
            // 
            this.RTB_PriInfo.BackColor = System.Drawing.SystemColors.Control;
            this.RTB_PriInfo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RTB_PriInfo.Location = new System.Drawing.Point(7, 20);
            this.RTB_PriInfo.Name = "RTB_PriInfo";
            this.RTB_PriInfo.Size = new System.Drawing.Size(297, 144);
            this.RTB_PriInfo.TabIndex = 0;
            this.RTB_PriInfo.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1632, 803);
            this.Controls.Add(this.GB_PrivateInfo);
            this.Controls.Add(this.btn_OpenCLA);
            this.Controls.Add(this.GB_Time);
            this.Controls.Add(this.btn_EveyStep);
            this.Controls.Add(this.GB_MC);
            this.Controls.Add(this.GB_OMU);
            this.Controls.Add(this.btn_Start);
            this.Controls.Add(this.GB_MicroOrder);
            this.Controls.Add(this.GB_DMU);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_InputFile);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.GBAssembly);
            this.Controls.Add(this.GBRigesterOther);
            this.Controls.Add(this.GBRegister);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "计算机模型机";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.GBRegister.ResumeLayout(false);
            this.GBRegister.PerformLayout();
            this.GBRigesterOther.ResumeLayout(false);
            this.GBRigesterOther.PerformLayout();
            this.GBAssembly.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.GB_DMU.ResumeLayout(false);
            this.GB_MicroOrder.ResumeLayout(false);
            this.GB_OMU.ResumeLayout(false);
            this.GB_MC.ResumeLayout(false);
            this.GB_Time.ResumeLayout(false);
            this.GB_PrivateInfo.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GBRegister;
        private System.Windows.Forms.Label Label_R3;
        private System.Windows.Forms.Label Label_R2;
        private System.Windows.Forms.Label Label_R1;
        private System.Windows.Forms.Label Label_R0;
        private System.Windows.Forms.TextBox Textbox_R7;
        private System.Windows.Forms.TextBox Textbox_R6;
        private System.Windows.Forms.TextBox Textbox_R5;
        private System.Windows.Forms.TextBox Textbox_R4;
        private System.Windows.Forms.Label Label_R7;
        private System.Windows.Forms.Label Label_R6;
        private System.Windows.Forms.Label Label_R5;
        private System.Windows.Forms.Label Label_R4;
        private System.Windows.Forms.TextBox Textbox_R3;
        private System.Windows.Forms.TextBox Textbox_R2;
        private System.Windows.Forms.TextBox Textbox_R1;
        private System.Windows.Forms.TextBox Textbox_R0;
        private System.Windows.Forms.GroupBox GBRigesterOther;
        private System.Windows.Forms.TextBox Textbox_IMDR;
        private System.Windows.Forms.TextBox Textbox_IMAR;
        private System.Windows.Forms.TextBox Textbox_MDR;
        private System.Windows.Forms.TextBox Textbox_IR;
        private System.Windows.Forms.Label Label_IMDR;
        private System.Windows.Forms.Label Label_IMAR;
        private System.Windows.Forms.Label Label_MDR;
        private System.Windows.Forms.Label Label_IR;
        private System.Windows.Forms.TextBox Textbox_DR;
        private System.Windows.Forms.TextBox Textbox_SR;
        private System.Windows.Forms.TextBox Textbox_MAR;
        private System.Windows.Forms.TextBox Textbox_PC;
        private System.Windows.Forms.Label Label_DR;
        private System.Windows.Forms.Label Label_SR;
        private System.Windows.Forms.Label Label_MAR;
        private System.Windows.Forms.Label Label_PC;
        private System.Windows.Forms.Label Label_PSW;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Textbox_PSW;
        private System.Windows.Forms.GroupBox GBAssembly;
        private System.Windows.Forms.ListBox Listbox_Code;
        private System.Windows.Forms.Button btn_Reset;
        private System.Windows.Forms.Button btn_InputFile;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox GB_DMU;
        private System.Windows.Forms.ListView Listview_DataMemory;
        private System.Windows.Forms.GroupBox GB_MicroOrder;
        private System.Windows.Forms.ListBox Listbox_MicroOrder;
        private System.Windows.Forms.Button btn_Start;
        private System.Windows.Forms.GroupBox GB_OMU;
        private System.Windows.Forms.ListView Listview_OrderMemory;
        private System.Windows.Forms.ColumnHeader ColumnHeader_Name;
        private System.Windows.Forms.ColumnHeader ColumnHeader_Code;
        private System.Windows.Forms.GroupBox GB_MC;
        private System.Windows.Forms.ListBox Listbox_MachineCode;
        private System.Windows.Forms.Button btn_EveyStep;
        private System.Windows.Forms.GroupBox GB_Time;
        private System.Windows.Forms.Button btn_OpenCLA;
        private System.Windows.Forms.ListBox Listbox_Time;
        private System.Windows.Forms.GroupBox GB_PrivateInfo;
        private System.Windows.Forms.RichTextBox RTB_PriInfo;
    }
}

